function next() { 
    document.getElementById('info1_container').style.display = 'none'; 
    document.getElementById('info2_container').style.display = 'block';
  }
  
  function previous() {
    document.getElementById('info2_container').style.display = 'none'; 
    document.getElementById('info1_container').style.display = 'block';
  }